const getTrackerIconClassName = id => {
  return 'icon_' + id;
};

export default getTrackerIconClassName;