const getTrackersJson = async () => {
  return require('../trackers.json');
};

export default getTrackersJson;